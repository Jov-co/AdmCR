package com.example.AdmCR;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AdmCrApplication {

	public static void main(String[] args) {
		SpringApplication.run(AdmCrApplication.class, args);


	}

}
